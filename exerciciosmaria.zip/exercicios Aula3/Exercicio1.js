//exercicio 1: operador  && (E)

let a = true;
let b = false;

console.log(a && b); // falso
console.log(a && true); // verdadeiro
console.log(b && false); //falso
console.log( a && (b || true)); // verdadeiro


