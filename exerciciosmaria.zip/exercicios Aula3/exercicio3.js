// exercicio 3: operador NÃO (!)

let z = true;

console.log(!z); // falso
console.log(!false); // verdadeiro
console.log(!(z && false)); // verdadeiro
console.log(!z || false); // falso
